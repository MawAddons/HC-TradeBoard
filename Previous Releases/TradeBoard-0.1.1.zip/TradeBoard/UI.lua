local TB = TradeBoard

TB.Frames = {}

local MAIN_BACKDROP = {
    bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
    edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
    tile = 1,
    tileSize = 32,
    edgeSize = 32,
    insets = { left = 10, right = 10, top = 10, bottom = 10 },
}

local PANEL_BACKDROP = {
    bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
    edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
    tile = 1,
    tileSize = 16,
    edgeSize = 14,
    insets = { left = 3, right = 3, top = 3, bottom = 3 },
}

local GOLD_R = 0.86
local GOLD_G = 0.66
local GOLD_B = 0.24

local function CreatePanel(parent, width, height)
    local panel = CreateFrame("Frame", nil, parent)
    panel:SetWidth(width)
    panel:SetHeight(height)
    panel:SetBackdrop(PANEL_BACKDROP)
    panel:SetBackdropColor(0.025, 0.025, 0.025, 0.96)
    panel:SetBackdropBorderColor(0.42, 0.34, 0.18, 1)
    return panel
end

local function CreateText(parent, text, font, r, g, b)
    local label = parent:CreateFontString(nil, "OVERLAY", font or "GameFontHighlightSmall")
    label:SetText(text or "")
    if r then
        label:SetTextColor(r, g, b)
    end
    return label
end

local function CreateButton(parent, text, width, height)
    local button = CreateFrame("Button", nil, parent)
    button:SetWidth(width)
    button:SetHeight(height)
    button:SetBackdrop(PANEL_BACKDROP)
    button:SetBackdropColor(0.18, 0.045, 0.018, 1)
    button:SetBackdropBorderColor(0.62, 0.40, 0.14, 1)

    local fill = button:CreateTexture(nil, "BACKGROUND")
    fill:SetTexture(0.18, 0.045, 0.018, 0.95)
    fill:SetPoint("TOPLEFT", button, "TOPLEFT", 4, -4)
    fill:SetPoint("BOTTOMRIGHT", button, "BOTTOMRIGHT", -4, 4)
    button.fill = fill

    local highlight = button:CreateTexture(nil, "HIGHLIGHT")
    highlight:SetTexture(0.75, 0.45, 0.12, 0.20)
    highlight:SetPoint("TOPLEFT", button, "TOPLEFT", 4, -4)
    highlight:SetPoint("BOTTOMRIGHT", button, "BOTTOMRIGHT", -4, 4)

    local label = CreateText(button, text, "GameFontNormal")
    label:SetPoint("CENTER", button, "CENTER", 0, 0)
    label:SetTextColor(1.00, 0.82, 0.24)
    button.label = label

    return button
end

local function SetButtonSelected(button, selected)
    if selected then
        button:SetBackdropColor(0.26, 0.10, 0.02, 1)
        button:SetBackdropBorderColor(0.95, 0.66, 0.18, 1)
        button.label:SetTextColor(1.00, 0.84, 0.26)
    else
        button:SetBackdropColor(0.055, 0.055, 0.055, 1)
        button:SetBackdropBorderColor(0.34, 0.28, 0.16, 1)
        button.label:SetTextColor(0.83, 0.74, 0.58)
    end
end

local function CreateCheckButton(parent, text, width, checked, callback, r, g, b)
    local button = CreateFrame("Button", nil, parent)
    button:SetWidth(width)
    button:SetHeight(24)
    button.checked = checked

    local box = button:CreateTexture(nil, "ARTWORK")
    box:SetTexture("Interface\\Buttons\\UI-CheckBox-Up")
    box:SetWidth(24)
    box:SetHeight(24)
    box:SetPoint("LEFT", button, "LEFT", 0, 0)
    button.box = box

    local check = button:CreateTexture(nil, "OVERLAY")
    check:SetTexture("Interface\\Buttons\\UI-CheckBox-Check")
    check:SetWidth(24)
    check:SetHeight(24)
    check:SetPoint("CENTER", box, "CENTER", 0, 0)
    button.check = check

    local highlight = button:CreateTexture(nil, "HIGHLIGHT")
    highlight:SetTexture(1.00, 0.78, 0.20, 0.20)
    highlight:SetWidth(18)
    highlight:SetHeight(18)
    highlight:SetPoint("CENTER", box, "CENTER", 0, 0)

    local label = CreateText(button, text, "GameFontHighlightSmall", r or 0.90, g or 0.86, b or 0.76)
    label:SetPoint("LEFT", box, "RIGHT", 2, 1)
    label:SetJustifyH("LEFT")
    button.label = label

    function button:SetCheckedValue(value)
        self.checked = value
        if value then
            self.check:Show()
        else
            self.check:Hide()
        end
    end

    button:SetCheckedValue(checked)
    button:SetScript("OnClick", function()
        if this.checked then
            this:SetCheckedValue(nil)
        else
            this:SetCheckedValue(1)
        end
        if callback then
            callback(this.checked)
        end
    end)

    return button
end

local function CreateEditBox(parent, width, height, text)
    local edit = CreateFrame("EditBox", nil, parent)
    edit:SetWidth(width)
    edit:SetHeight(height)
    edit:SetAutoFocus(nil)
    edit:SetFont("Fonts\\FRIZQT__.TTF", 12, "")
    edit:SetTextColor(0.95, 0.90, 0.78)
    edit:SetJustifyH("LEFT")
    edit:SetBackdrop(PANEL_BACKDROP)
    edit:SetBackdropColor(0.01, 0.01, 0.01, 1)
    edit:SetBackdropBorderColor(0.35, 0.30, 0.20, 1)
    if edit.SetTextInsets then
        edit:SetTextInsets(7, 7, 0, 0)
    end
    edit:SetText(text or "")
    edit:SetScript("OnEscapePressed", function()
        this:ClearFocus()
    end)
    return edit
end

local function CreateHeading(parent, text)
    local heading = CreateText(parent, text, "GameFontNormal", 1.00, 0.78, 0.24)
    heading:SetPoint("TOP", parent, "TOP", 0, -9)
    return heading
end

function TB:CreateMainFrame()
    local frame = CreateFrame("Frame", "TradeBoardFrame", UIParent)
    frame:SetWidth(960)
    frame:SetHeight(680)
    frame:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
    frame:SetFrameStrata("HIGH")
    frame:SetMovable(1)
    if frame.SetClampedToScreen then
        frame:SetClampedToScreen(1)
    end
    frame:EnableMouse(1)
    frame:SetBackdrop(MAIN_BACKDROP)
    frame:SetBackdropColor(0.018, 0.018, 0.018, 0.98)
    frame:SetBackdropBorderColor(0.54, 0.42, 0.18, 1)
    self.Frames.main = frame

    local header = CreateFrame("Frame", nil, frame)
    header:SetPoint("TOPLEFT", frame, "TOPLEFT", 18, -13)
    header:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -18, -13)
    header:SetHeight(36)
    header:EnableMouse(1)
    header:RegisterForDrag("LeftButton")
    header:SetScript("OnDragStart", function()
        TradeBoardFrame:StartMoving()
    end)
    header:SetScript("OnDragStop", function()
        TradeBoardFrame:StopMovingOrSizing()
    end)

    local headerBg = header:CreateTexture(nil, "BACKGROUND")
    headerBg:SetTexture(0.025, 0.025, 0.025, 1)
    headerBg:SetAllPoints(header)

    local title = CreateText(header, "TradeBoard", "GameFontNormalLarge", 1.00, 0.78, 0.20)
    title:SetPoint("CENTER", header, "CENTER", 0, 1)

    local version = CreateText(header, "UI prototype  v" .. self.VERSION, "GameFontDisableSmall", 0.55, 0.50, 0.40)
    version:SetPoint("LEFT", header, "LEFT", 8, 0)

    local close = CreateButton(header, "X", 30, 28)
    close:SetPoint("RIGHT", header, "RIGHT", -2, 0)
    close:SetScript("OnClick", function()
        TradeBoardFrame:Hide()
    end)

    local content = CreateFrame("Frame", nil, frame)
    content:SetPoint("TOPLEFT", frame, "TOPLEFT", 16, -94)
    content:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -16, 48)
    self.Frames.content = content

    self:CreateTabs(frame)
    self:CreateBrowsePane(content)
    self:CreateMyListingsPane(content)
    self:CreateTradeChainsPane(content)

    local statusBar = CreateFrame("Frame", nil, frame)
    statusBar:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 18, 15)
    statusBar:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -18, 15)
    statusBar:SetHeight(24)
    statusBar:SetBackdrop(PANEL_BACKDROP)
    statusBar:SetBackdropColor(0.025, 0.025, 0.025, 1)
    statusBar:SetBackdropBorderColor(0.30, 0.25, 0.15, 1)

    local statusText = CreateText(statusBar, "Mock listings: no market-channel traffic.", "GameFontHighlightSmall", 0.70, 0.67, 0.58)
    statusText:SetPoint("LEFT", statusBar, "LEFT", 8, 0)
    self.Frames.statusText = statusText

    table.insert(UISpecialFrames, "TradeBoardFrame")
end

function TB:CreateTabs(parent)
    self.Frames.tabs = {}
    local names = { "Browse", "My Listings", "Trade Chains" }
    local widths = { 130, 150, 150 }
    local x = 24
    local i

    for i = 1, table.getn(names) do
        local tabName = names[i]
        local tab = CreateButton(parent, tabName, widths[i], 34)
        tab:SetPoint("TOPLEFT", parent, "TOPLEFT", x, -55)
        tab:SetScript("OnClick", function()
            TB:SetActiveTab(tabName)
        end)
        self.Frames.tabs[tabName] = tab
        x = x + widths[i] + 6
    end
end

function TB:CreateBrowsePane(parent)
    local pane = CreateFrame("Frame", nil, parent)
    pane:SetAllPoints(parent)
    self.Frames.browsePane = pane

    local searchPanel = CreatePanel(pane, 928, 42)
    searchPanel:SetPoint("TOPLEFT", pane, "TOPLEFT", 0, 0)

    local searchField = CreateEditBox(searchPanel, 900, 28, "")
    searchField:SetPoint("CENTER", searchPanel, "CENTER", 0, 0)
    searchField:SetMaxLetters(60)
    self.Frames.searchField = searchField

    local placeholder = CreateText(searchPanel, "Search items...", "GameFontDisable", 0.50, 0.48, 0.44)
    placeholder:SetPoint("LEFT", searchField, "LEFT", 8, 0)
    self.Frames.searchPlaceholder = placeholder

    searchField:SetScript("OnTextChanged", function()
        if this:GetText() == "" then
            TB.Frames.searchPlaceholder:Show()
        else
            TB.Frames.searchPlaceholder:Hide()
        end
    end)
    searchField:SetScript("OnEnterPressed", function()
        this:ClearFocus()
        TB:UpdateBrowse()
    end)

    self:CreateCategoryPanel(pane)
    self:CreateFilterPanels(pane)
    self:CreateResultsPanel(pane)

    local countText = CreateText(pane, "0 matching listings", "GameFontHighlightSmall", 0.83, 0.77, 0.65)
    countText:SetPoint("BOTTOMLEFT", pane, "BOTTOMLEFT", 185, 8)
    self.Frames.resultCount = countText

    local listButton = CreateButton(pane, "List an Item", 126, 34)
    listButton:SetPoint("BOTTOMRIGHT", pane, "BOTTOMRIGHT", 0, 0)
    listButton:SetScript("OnClick", function()
        TB:SetActiveTab("My Listings")
        TB:SetStatus("Mock mode: listing editor will be added after the visual shell is approved.")
    end)

    local refreshButton = CreateButton(pane, "Refresh", 100, 34)
    refreshButton:SetPoint("RIGHT", listButton, "LEFT", -8, 0)
    refreshButton:SetScript("OnClick", function()
        TB:UpdateBrowse()
        TB:SetStatus("Mock listings refreshed locally. No messages were sent.")
    end)

    local addFriendButton = CreateButton(pane, "Add Friend", 108, 34)
    addFriendButton:SetPoint("RIGHT", refreshButton, "LEFT", -8, 0)
    addFriendButton:SetScript("OnClick", function()
        local listing = TB.State.selectedListing
        if listing then
            AddFriend(listing.trader)
            TB:SetStatus("Friend request sent for " .. listing.trader .. ".")
        else
            TB:SetStatus("Select a listing before adding its trader.")
        end
    end)

    local whisperButton = CreateButton(pane, "Whisper", 100, 34)
    whisperButton:SetPoint("RIGHT", addFriendButton, "LEFT", -8, 0)
    whisperButton:SetScript("OnClick", function()
        local listing = TB.State.selectedListing
        if listing then
            ChatFrame_OpenChat("/w " .. listing.trader .. " ")
            TB:SetStatus("Whisper opened for " .. listing.trader .. ".")
        else
            TB:SetStatus("Select a listing before whispering its trader.")
        end
    end)
end

function TB:CreateCategoryPanel(parent)
    local panel = CreatePanel(parent, 170, 438)
    panel:SetPoint("TOPLEFT", parent, "TOPLEFT", 0, -50)
    CreateHeading(panel, "Categories")
    self.Frames.categoryPanel = panel
    self.Frames.categoryButtons = {}

    local i
    for i = 1, table.getn(self.Categories) do
        local category = self.Categories[i]
        local button = CreateButton(panel, category, 150, 30)
        button:SetPoint("TOPLEFT", panel, "TOPLEFT", 10, -34 - ((i - 1) * 37))
        button.label:ClearAllPoints()
        button.label:SetPoint("LEFT", button, "LEFT", 10, 0)
        button.label:SetJustifyH("LEFT")
        button:SetScript("OnClick", function()
            TB.State.category = category
            TB.State.browseOffset = 0
            TB:UpdateBrowse()
        end)
        self.Frames.categoryButtons[category] = button
    end
end

function TB:CreateFilterPanels(parent)
    local trader = CreatePanel(parent, 198, 150)
    trader:SetPoint("TOPLEFT", parent, "TOPLEFT", 178, -50)
    CreateHeading(trader, "Trader")

    local rangeCheck = CreateCheckButton(trader, self:GetTraderRangeLabel(), 178, self.State.myLevelRange, function(value)
        TB.State.myLevelRange = value
        TB.State.browseOffset = 0
        TB:UpdateBrowse()
    end)
    rangeCheck:SetPoint("TOPLEFT", trader, "TOPLEFT", 10, -44)
    self.Frames.rangeCheck = rangeCheck

    local onlineCheck = CreateCheckButton(trader, "Online only", 178, self.State.onlineOnly, function(value)
        TB.State.onlineOnly = value
        TB.State.browseOffset = 0
        TB:UpdateBrowse()
    end)
    onlineCheck:SetPoint("TOPLEFT", trader, "TOPLEFT", 10, -82)
    self.Frames.onlineCheck = onlineCheck

    local levelPanel = CreatePanel(parent, 170, 150)
    levelPanel:SetPoint("TOPLEFT", parent, "TOPLEFT", 382, -50)
    CreateHeading(levelPanel, "Item Level")

    local levelType = CreateButton(levelPanel, "Required Level", 146, 30)
    levelType:SetPoint("TOPLEFT", levelPanel, "TOPLEFT", 12, -38)
    levelType:SetScript("OnClick", function()
        if TB.State.levelType == "required" then
            TB.State.levelType = "item"
        else
            TB.State.levelType = "required"
        end
        TB.State.browseOffset = 0
        TB:UpdateBrowse()
    end)
    self.Frames.levelTypeButton = levelType

    local minLabel = CreateText(levelPanel, "Min", "GameFontHighlightSmall", 0.80, 0.74, 0.62)
    minLabel:SetPoint("TOPLEFT", levelPanel, "TOPLEFT", 26, -79)
    local maxLabel = CreateText(levelPanel, "Max", "GameFontHighlightSmall", 0.80, 0.74, 0.62)
    maxLabel:SetPoint("TOPLEFT", levelPanel, "TOPLEFT", 104, -79)

    local minEdit = CreateEditBox(levelPanel, 58, 30, tostring(self.State.minLevel))
    minEdit:SetPoint("TOPLEFT", levelPanel, "TOPLEFT", 12, -101)
    minEdit:SetMaxLetters(3)
    minEdit:SetJustifyH("CENTER")
    self.Frames.minLevel = minEdit

    local maxEdit = CreateEditBox(levelPanel, 58, 30, tostring(self.State.maxLevel))
    maxEdit:SetPoint("TOPLEFT", levelPanel, "TOPLEFT", 90, -101)
    maxEdit:SetMaxLetters(3)
    maxEdit:SetJustifyH("CENTER")
    self.Frames.maxLevel = maxEdit

    minEdit:SetScript("OnEnterPressed", function()
        this:ClearFocus()
        TB:UpdateBrowse()
    end)
    maxEdit:SetScript("OnEnterPressed", function()
        this:ClearFocus()
        TB:UpdateBrowse()
    end)

    local rarity = CreatePanel(parent, 218, 150)
    rarity:SetPoint("TOPLEFT", parent, "TOPLEFT", 558, -50)
    CreateHeading(rarity, "Rarity")
    self.Frames.rarityChecks = {}

    local quality
    for quality = 1, 5 do
        local qualityIndex = quality
        local info = self.Quality[quality]
        local check = CreateCheckButton(rarity, info.name, 195, self.State.rarities[quality], function(value)
            TB.State.rarities[qualityIndex] = value
            TB.State.browseOffset = 0
            TB:UpdateBrowse()
        end, info.r, info.g, info.b)
        check:SetPoint("TOPLEFT", rarity, "TOPLEFT", 10, -30 - ((quality - 1) * 23))
        self.Frames.rarityChecks[quality] = check
    end

    local actions = CreatePanel(parent, 146, 150)
    actions:SetPoint("TOPLEFT", parent, "TOPLEFT", 782, -50)

    local sellCheck = CreateCheckButton(actions, "Sell", 120, self.State.showSell, function(value)
        TB.State.showSell = value
        TB.State.browseOffset = 0
        TB:UpdateBrowse()
    end)
    sellCheck:SetPoint("TOPLEFT", actions, "TOPLEFT", 10, -10)
    self.Frames.sellCheck = sellCheck

    local buyCheck = CreateCheckButton(actions, "Buy", 120, self.State.showBuy, function(value)
        TB.State.showBuy = value
        TB.State.browseOffset = 0
        TB:UpdateBrowse()
    end)
    buyCheck:SetPoint("TOPLEFT", actions, "TOPLEFT", 10, -39)
    self.Frames.buyCheck = buyCheck

    local clear = CreateButton(actions, "Clear Filters", 124, 30)
    clear:SetPoint("TOPLEFT", actions, "TOPLEFT", 11, -73)
    clear:SetScript("OnClick", function()
        TB:ResetFilters()
        TB:SyncFilterControls()
        TB:UpdateBrowse()
        TB:SetStatus("All local filters cleared.")
    end)

    local search = CreateButton(actions, "Search", 124, 30)
    search:SetPoint("TOPLEFT", actions, "TOPLEFT", 11, -109)
    search:SetScript("OnClick", function()
        TB:UpdateBrowse()
    end)
end

function TB:CreateResultsPanel(parent)
    local panel = CreatePanel(parent, 750, 280)
    panel:SetPoint("TOPLEFT", parent, "TOPLEFT", 178, -208)
    panel:EnableMouseWheel(1)
    panel:SetScript("OnMouseWheel", function()
        local filtered = TB:GetFilteredListings()
        local maxOffset = table.getn(filtered) - TB.MAX_VISIBLE_ROWS
        if maxOffset < 0 then
            maxOffset = 0
        end

        if arg1 > 0 then
            TB.State.browseOffset = TB.State.browseOffset - 1
        else
            TB.State.browseOffset = TB.State.browseOffset + 1
        end

        if TB.State.browseOffset < 0 then
            TB.State.browseOffset = 0
        end
        if TB.State.browseOffset > maxOffset then
            TB.State.browseOffset = maxOffset
        end
        TB:UpdateBrowseRows(filtered)
    end)
    self.Frames.resultsPanel = panel

    local header = CreateFrame("Frame", nil, panel)
    header:SetPoint("TOPLEFT", panel, "TOPLEFT", 5, -5)
    header:SetPoint("TOPRIGHT", panel, "TOPRIGHT", -5, -5)
    header:SetHeight(28)
    local headerBg = header:CreateTexture(nil, "BACKGROUND")
    headerBg:SetTexture(0.14, 0.12, 0.075, 0.95)
    headerBg:SetAllPoints(header)

    local columns = {
        { text = "Item Name", x = 8, width = 220, sortKey = "name" },
        { text = "Qty", x = 232, width = 38, sortKey = "quantity" },
        { text = "Req", x = 272, width = 40, sortKey = "requiredLevel" },
        { text = "iLvl", x = 314, width = 40, sortKey = "itemLevel" },
        { text = "Unit Price", x = 358, width = 80, sortKey = "unitPrice" },
        { text = "Trader", x = 442, width = 88, sortKey = "trader" },
        { text = "Trader Lv", x = 534, width = 64, sortKey = "traderLevel" },
        { text = "Status", x = 602, width = 75, sortKey = "online" },
    }

    self.Frames.sortHeaders = {}
    local i
    for i = 1, table.getn(columns) do
        local column = columns[i]
        local sortKey = column.sortKey
        local headerText = column.text
        local sortButton = CreateFrame("Button", nil, header)
        sortButton:SetPoint("TOPLEFT", header, "TOPLEFT", column.x, 0)
        sortButton:SetWidth(column.width)
        sortButton:SetHeight(28)

        local hover = sortButton:CreateTexture(nil, "HIGHLIGHT")
        hover:SetTexture(0.90, 0.64, 0.18, 0.16)
        hover:SetAllPoints(sortButton)

        local label = CreateText(sortButton, headerText, "GameFontNormalSmall", 0.92, 0.78, 0.45)
        label:SetPoint("LEFT", sortButton, "LEFT", 0, 0)
        label:SetWidth(column.width - 13)
        label:SetJustifyH("LEFT")

        local arrow = sortButton:CreateTexture(nil, "ARTWORK")
        arrow:SetTexture("Interface\\Buttons\\UI-SortArrow")
        arrow:SetWidth(9)
        arrow:SetHeight(8)
        arrow:SetPoint("RIGHT", sortButton, "RIGHT", -2, -1)
        arrow:Hide()

        sortButton.label = label
        sortButton.arrow = arrow
        sortButton.sortKey = sortKey
        sortButton:SetScript("OnClick", function()
            TB:SetSort(sortKey)
            TB:UpdateBrowse()
            local direction = TB.State.sortAscending and "ascending" or "descending"
            TB:SetStatus("Sorted by " .. headerText .. " (" .. direction .. ").")
        end)
        sortButton:SetScript("OnEnter", function()
            GameTooltip:SetOwner(this, "ANCHOR_TOP")
            GameTooltip:SetText("Sort by " .. headerText, 1.00, 0.82, 0.24)
            GameTooltip:AddLine("Click again to reverse the order.", 0.75, 0.72, 0.64)
            GameTooltip:Show()
        end)
        sortButton:SetScript("OnLeave", function()
            GameTooltip:Hide()
        end)

        self.Frames.sortHeaders[sortKey] = sortButton
    end

    self.Frames.resultRows = {}
    for i = 1, self.MAX_VISIBLE_ROWS do
        local row = CreateFrame("Button", nil, panel)
        row:SetPoint("TOPLEFT", panel, "TOPLEFT", 6, -35 - ((i - 1) * 34))
        row:SetWidth(738)
        row:SetHeight(32)

        local bg = row:CreateTexture(nil, "BACKGROUND")
        if math.mod(i, 2) == 0 then
            bg:SetTexture(0.055, 0.055, 0.050, 0.90)
        else
            bg:SetTexture(0.025, 0.025, 0.025, 0.90)
        end
        bg:SetAllPoints(row)

        local selected = row:CreateTexture(nil, "ARTWORK")
        selected:SetTexture(0.75, 0.48, 0.12, 0.20)
        selected:SetAllPoints(row)
        selected:Hide()
        row.selected = selected

        local highlight = row:CreateTexture(nil, "HIGHLIGHT")
        highlight:SetTexture(0.75, 0.48, 0.12, 0.12)
        highlight:SetAllPoints(row)

        local icon = row:CreateTexture(nil, "ARTWORK")
        icon:SetWidth(27)
        icon:SetHeight(27)
        icon:SetPoint("LEFT", row, "LEFT", 3, 0)
        row.icon = icon

        local name = CreateText(row, "", "GameFontHighlightSmall")
        name:SetPoint("LEFT", row, "LEFT", 34, 0)
        name:SetWidth(192)
        name:SetJustifyH("LEFT")
        row.itemName = name

        local function RowText(x, width, justify)
            local text = CreateText(row, "", "GameFontHighlightSmall", 0.86, 0.82, 0.74)
            text:SetPoint("LEFT", row, "LEFT", x, 0)
            text:SetWidth(width)
            text:SetJustifyH(justify or "LEFT")
            return text
        end

        row.quantity = RowText(232, 36, "CENTER")
        row.required = RowText(272, 38, "CENTER")
        row.itemLevel = RowText(314, 38, "CENTER")
        row.price = RowText(358, 78, "RIGHT")
        row.trader = RowText(442, 86, "LEFT")
        row.traderLevel = RowText(534, 62, "CENTER")
        row.status = RowText(602, 76, "LEFT")

        row:SetScript("OnClick", function()
            if this.listing then
                TB.State.selectedListing = this.listing
                TB:UpdateBrowse()
                TB:SetStatus("Selected " .. this.listing.name .. " from " .. this.listing.trader .. ".")
            end
        end)
        row:SetScript("OnEnter", function()
            if this.listing then
                GameTooltip:SetOwner(this, "ANCHOR_RIGHT")
                local info = TB.Quality[this.listing.quality]
                GameTooltip:SetText(this.listing.name, info.r, info.g, info.b)
                GameTooltip:AddLine("Mock " .. this.listing.orderType .. " listing", 0.80, 0.75, 0.62)
                GameTooltip:AddLine("Required level " .. this.listing.requiredLevel .. "   Item level " .. this.listing.itemLevel, 1, 1, 1)
                GameTooltip:AddLine("Trader: " .. this.listing.trader .. " (level " .. this.listing.traderLevel .. ")", 0.70, 0.85, 1)
                GameTooltip:AddLine("No channel message will be sent.", 0.55, 0.55, 0.55)
                GameTooltip:Show()
            end
        end)
        row:SetScript("OnLeave", function()
            GameTooltip:Hide()
        end)

        self.Frames.resultRows[i] = row
    end

    local scrollHint = CreateText(panel, "Mouse wheel scrolls", "GameFontDisableSmall", 0.45, 0.43, 0.38)
    scrollHint:SetPoint("BOTTOMRIGHT", panel, "BOTTOMRIGHT", -8, 5)
end

function TB:CreateMyListingsPane(parent)
    local pane = CreateFrame("Frame", nil, parent)
    pane:SetAllPoints(parent)
    pane:Hide()
    self.Frames.myListingsPane = pane

    local title = CreateText(pane, "My Listings", "GameFontNormalLarge", 1.00, 0.78, 0.20)
    title:SetPoint("TOPLEFT", pane, "TOPLEFT", 8, -8)
    local subtitle = CreateText(pane, "Local mock data only - nothing here is advertised.", "GameFontHighlightSmall", 0.66, 0.63, 0.56)
    subtitle:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -6)

    local panel = CreatePanel(pane, 912, 350)
    panel:SetPoint("TOPLEFT", pane, "TOPLEFT", 8, -58)

    local headers = { "Item", "Quantity", "Unit Price", "Status" }
    local headerX = { 18, 480, 610, 780 }
    local i
    for i = 1, table.getn(headers) do
        local label = CreateText(panel, headers[i], "GameFontNormal", 0.92, 0.78, 0.45)
        label:SetPoint("TOPLEFT", panel, "TOPLEFT", headerX[i], -16)
    end

    for i = 1, table.getn(self.MockMyListings) do
        local item = self.MockMyListings[i]
        local row = CreateFrame("Button", nil, panel)
        row:SetPoint("TOPLEFT", panel, "TOPLEFT", 10, -48 - ((i - 1) * 72))
        row:SetWidth(892)
        row:SetHeight(62)

        local bg = row:CreateTexture(nil, "BACKGROUND")
        bg:SetTexture(0.035, 0.035, 0.032, 0.92)
        bg:SetAllPoints(row)
        local hl = row:CreateTexture(nil, "HIGHLIGHT")
        hl:SetTexture(0.72, 0.46, 0.12, 0.12)
        hl:SetAllPoints(row)

        local icon = row:CreateTexture(nil, "ARTWORK")
        icon:SetTexture(item.texture)
        icon:SetWidth(46)
        icon:SetHeight(46)
        icon:SetPoint("LEFT", row, "LEFT", 8, 0)

        local info = self.Quality[item.quality]
        local name = CreateText(row, item.name, "GameFontNormal", info.r, info.g, info.b)
        name:SetPoint("LEFT", row, "LEFT", 65, 0)
        local qty = CreateText(row, tostring(item.quantity), "GameFontHighlight", 0.90, 0.86, 0.76)
        qty:SetPoint("LEFT", row, "LEFT", 485, 0)
        local price = CreateText(row, self:FormatMoney(item.price), "GameFontHighlight", 0.90, 0.86, 0.76)
        price:SetPoint("LEFT", row, "LEFT", 615, 0)
        local statusColor = 0.20
        if item.status == "Active" then
            statusColor = 0.30
        end
        local status = CreateText(row, item.status, "GameFontHighlight", statusColor, item.status == "Active" and 0.95 or 0.65, 0.25)
        status:SetPoint("LEFT", row, "LEFT", 785, 0)

        row:SetScript("OnClick", function()
            TB:SetStatus("Selected a local mock listing.")
        end)
    end

    local newButton = CreateButton(pane, "New Mock Listing", 150, 36)
    newButton:SetPoint("BOTTOMRIGHT", pane, "BOTTOMRIGHT", 0, 0)
    newButton:SetScript("OnClick", function()
        TB:SetStatus("The posting form is intentionally mocked in this visual prototype.")
    end)

    local removeButton = CreateButton(pane, "Remove", 100, 36)
    removeButton:SetPoint("RIGHT", newButton, "LEFT", -8, 0)
    removeButton:SetScript("OnClick", function()
        TB:SetStatus("Mock action only: no listing was removed.")
    end)

    local editButton = CreateButton(pane, "Edit", 100, 36)
    editButton:SetPoint("RIGHT", removeButton, "LEFT", -8, 0)
    editButton:SetScript("OnClick", function()
        TB:SetStatus("Mock action only: posting editor is not connected yet.")
    end)
end

function TB:CreateTradeChainsPane(parent)
    local pane = CreateFrame("Frame", nil, parent)
    pane:SetAllPoints(parent)
    pane:Hide()
    self.Frames.tradeChainsPane = pane

    local intro = CreateText(pane, "Trade chains bridge goods through legal 5-level handoffs.", "GameFontNormal", 0.90, 0.82, 0.66)
    intro:SetPoint("TOPLEFT", pane, "TOPLEFT", 8, -8)

    local listPanel = CreatePanel(pane, 180, 430)
    listPanel:SetPoint("TOPLEFT", pane, "TOPLEFT", 0, -42)
    CreateHeading(listPanel, "Listed Chains")

    self.Frames.chainButtons = {}
    local i
    for i = 1, table.getn(self.MockChains) do
        local chainIndex = i
        local chain = self.MockChains[i]
        local button = CreateButton(listPanel, chain.name, 158, 36)
        button:SetPoint("TOPLEFT", listPanel, "TOPLEFT", 11, -40 - ((i - 1) * 45))
        button.label:ClearAllPoints()
        button.label:SetPoint("LEFT", button, "LEFT", 10, 0)
        button:SetScript("OnClick", function()
            TB.State.selectedChain = chainIndex
            TB:UpdateTradeChains()
        end)
        self.Frames.chainButtons[i] = button
    end

    local detail = CreatePanel(pane, 738, 430)
    detail:SetPoint("TOPLEFT", pane, "TOPLEFT", 190, -42)
    self.Frames.chainDetail = detail

    local chainTitle = CreateText(detail, "", "GameFontNormalLarge", 1.00, 0.78, 0.20)
    chainTitle:SetPoint("TOP", detail, "TOP", 0, -15)
    self.Frames.chainTitle = chainTitle

    local positions = {
        { 20, -70 }, { 194, -70 }, { 368, -70 }, { 542, -70 },
        { 542, -178 }, { 368, -178 }, { 194, -178 }, { 20, -178 },
        { 20, -286 }, { 194, -286 }, { 368, -286 }, { 542, -286 },
    }

    self.Frames.chainNodes = {}
    for i = 1, 12 do
        local node = CreatePanel(detail, 150, 58)
        node:SetPoint("TOPLEFT", detail, "TOPLEFT", positions[i][1], positions[i][2])
        node:SetBackdropColor(0.045, 0.045, 0.042, 1)

        local level = CreateText(node, "", "GameFontNormal", 1.00, 0.78, 0.20)
        level:SetPoint("TOPLEFT", node, "TOPLEFT", 10, -8)
        node.level = level

        local name = CreateText(node, "", "GameFontHighlightSmall", 0.88, 0.84, 0.76)
        name:SetPoint("BOTTOMLEFT", node, "BOTTOMLEFT", 10, 8)
        node.memberName = name

        local dot = node:CreateTexture(nil, "ARTWORK")
        dot:SetTexture(1, 1, 1, 1)
        dot:SetWidth(10)
        dot:SetHeight(10)
        dot:SetPoint("RIGHT", node, "RIGHT", -10, 0)
        node.dot = dot

        self.Frames.chainNodes[i] = node
    end

    local function Line(x, y, width, height)
        local line = detail:CreateTexture(nil, "BACKGROUND")
        line:SetTexture(GOLD_R, GOLD_G, GOLD_B, 0.70)
        line:SetPoint("TOPLEFT", detail, "TOPLEFT", x, y)
        line:SetWidth(width)
        line:SetHeight(height)
    end

    Line(170, -98, 24, 3)
    Line(344, -98, 24, 3)
    Line(518, -98, 24, 3)
    Line(616, -128, 3, 50)
    Line(518, -206, 24, 3)
    Line(344, -206, 24, 3)
    Line(170, -206, 24, 3)
    Line(94, -236, 3, 50)
    Line(170, -314, 24, 3)
    Line(344, -314, 24, 3)
    Line(518, -314, 24, 3)

    local onlinePanel = CreatePanel(pane, 170, 42)
    onlinePanel:SetPoint("BOTTOMLEFT", pane, "BOTTOMLEFT", 190, 0)
    local onlineText = CreateText(onlinePanel, "", "GameFontNormal", 0.35, 1.00, 0.35)
    onlineText:SetPoint("CENTER", onlinePanel, "CENTER", 0, 0)
    self.Frames.chainOnline = onlineText

    local fullPanel = CreatePanel(pane, 170, 42)
    fullPanel:SetPoint("LEFT", onlinePanel, "RIGHT", 8, 0)
    local fullText = CreateText(fullPanel, "Full 5-60 chain", "GameFontNormal", 0.95, 0.82, 0.42)
    fullText:SetPoint("CENTER", fullPanel, "CENTER", 0, 0)

    local factionPanel = CreatePanel(pane, 170, 42)
    factionPanel:SetPoint("LEFT", fullPanel, "RIGHT", 8, 0)
    local factionText = CreateText(factionPanel, "", "GameFontNormal", 0.95, 0.82, 0.42)
    factionText:SetPoint("CENTER", factionPanel, "CENTER", 0, 0)
    self.Frames.chainFaction = factionText

    local listChain = CreateButton(pane, "List My Chain", 140, 42)
    listChain:SetPoint("BOTTOMRIGHT", pane, "BOTTOMRIGHT", 0, 0)
    listChain:SetScript("OnClick", function()
        TB:SetStatus("Mock mode: chain editor is not connected yet.")
    end)
end

function TB:SetActiveTab(tabName)
    self.State.activeTab = tabName
    self.Frames.browsePane:Hide()
    self.Frames.myListingsPane:Hide()
    self.Frames.tradeChainsPane:Hide()

    if tabName == "Browse" then
        self.Frames.browsePane:Show()
        self:UpdateBrowse()
    elseif tabName == "My Listings" then
        self.Frames.myListingsPane:Show()
    else
        self.Frames.tradeChainsPane:Show()
        self:UpdateTradeChains()
    end

    local name, tab
    for name, tab in pairs(self.Frames.tabs) do
        SetButtonSelected(tab, name == tabName)
    end
end

function TB:SyncFilterControls()
    local state = self.State
    self.Frames.searchField:SetText(state.search or "")
    self.Frames.rangeCheck:SetCheckedValue(state.myLevelRange)
    self.Frames.onlineCheck:SetCheckedValue(state.onlineOnly)
    self.Frames.sellCheck:SetCheckedValue(state.showSell)
    self.Frames.buyCheck:SetCheckedValue(state.showBuy)

    if state.minLevel and state.minLevel > 0 then
        self.Frames.minLevel:SetText(tostring(state.minLevel))
    else
        self.Frames.minLevel:SetText("")
    end
    if state.maxLevel and state.maxLevel > 0 then
        self.Frames.maxLevel:SetText(tostring(state.maxLevel))
    else
        self.Frames.maxLevel:SetText("")
    end

    local quality
    for quality = 1, 5 do
        self.Frames.rarityChecks[quality]:SetCheckedValue(state.rarities[quality])
    end
end

function TB:UpdateBrowse()
    local state = self.State
    state.search = self.Frames.searchField:GetText() or ""
    state.minLevel = tonumber(self.Frames.minLevel:GetText()) or 0
    state.maxLevel = tonumber(self.Frames.maxLevel:GetText()) or 0

    self.Frames.rangeCheck.label:SetText(self:GetTraderRangeLabel())
    if state.levelType == "required" then
        self.Frames.levelTypeButton.label:SetText("Required Level")
    else
        self.Frames.levelTypeButton.label:SetText("Item Level")
    end

    local category, button
    for category, button in pairs(self.Frames.categoryButtons) do
        SetButtonSelected(button, category == state.category)
    end

    local sortKey, sortHeader
    for sortKey, sortHeader in pairs(self.Frames.sortHeaders) do
        if sortKey == state.sortKey then
            sortHeader.arrow:Show()
            sortHeader.label:SetTextColor(1.00, 0.86, 0.32)
            if state.sortAscending then
                sortHeader.arrow:SetTexCoord(0, 0.5625, 1.0, 0)
            else
                sortHeader.arrow:SetTexCoord(0, 0.5625, 0, 1.0)
            end
        else
            sortHeader.arrow:Hide()
            sortHeader.label:SetTextColor(0.92, 0.78, 0.45)
        end
    end

    local filtered = self:GetFilteredListings()
    local maxOffset = table.getn(filtered) - self.MAX_VISIBLE_ROWS
    if maxOffset < 0 then
        maxOffset = 0
    end
    if state.browseOffset > maxOffset then
        state.browseOffset = maxOffset
    end
    if state.browseOffset < 0 then
        state.browseOffset = 0
    end

    self:UpdateBrowseRows(filtered)
end

function TB:UpdateBrowseRows(filtered)
    local total = table.getn(filtered)
    local offset = self.State.browseOffset
    local i

    for i = 1, self.MAX_VISIBLE_ROWS do
        local row = self.Frames.resultRows[i]
        local listing = filtered[offset + i]
        if listing then
            local info = self.Quality[listing.quality]
            row.listing = listing
            row.icon:SetTexture(listing.texture)
            if listing.orderType == "BUY" then
                row.itemName:SetText("WTB: " .. listing.name)
            else
                row.itemName:SetText(listing.name)
            end
            row.itemName:SetTextColor(info.r, info.g, info.b)
            row.quantity:SetText(tostring(listing.quantity))
            row.required:SetText(tostring(listing.requiredLevel))
            row.itemLevel:SetText(tostring(listing.itemLevel))
            row.price:SetText(self:FormatMoney(listing.unitPrice))
            row.trader:SetText(listing.trader)
            row.traderLevel:SetText(tostring(listing.traderLevel))
            if listing.online then
                row.status:SetText("Online")
                row.status:SetTextColor(0.20, 1.00, 0.20)
            else
                row.status:SetText("Offline")
                row.status:SetTextColor(0.55, 0.55, 0.55)
            end
            if self.State.selectedListing == listing then
                row.selected:Show()
            else
                row.selected:Hide()
            end
            row:Show()
        else
            row.listing = nil
            row:Hide()
        end
    end

    if total == 1 then
        self.Frames.resultCount:SetText("1 matching listing")
    else
        self.Frames.resultCount:SetText(total .. " matching listings")
    end
end

function TB:UpdateTradeChains()
    local index = self.State.selectedChain
    local chain = self.MockChains[index]
    if not chain then
        return
    end

    local i
    for i = 1, table.getn(self.Frames.chainButtons) do
        SetButtonSelected(self.Frames.chainButtons[i], i == index)
    end

    self.Frames.chainTitle:SetText(chain.name)
    local onlineCount = 0
    for i = 1, 12 do
        local member = chain.members[i]
        local node = self.Frames.chainNodes[i]
        node.level:SetText("Lv " .. member.level)
        node.memberName:SetText(member.name)
        if member.online then
            onlineCount = onlineCount + 1
            node.dot:SetVertexColor(0.20, 1.00, 0.20)
            node:SetBackdropBorderColor(0.45, 0.55, 0.22, 1)
        else
            node.dot:SetVertexColor(0.38, 0.38, 0.38)
            node:SetBackdropBorderColor(0.30, 0.28, 0.22, 1)
        end
    end

    self.Frames.chainOnline:SetText(onlineCount .. "/12 available")
    if chain.crossFaction then
        self.Frames.chainFaction:SetText("Cross-faction")
    else
        self.Frames.chainFaction:SetText("Same faction")
    end
end

function TB:Toggle()
    if self.Frames.main:IsShown() then
        self.Frames.main:Hide()
    else
        self.Frames.main:Show()
        self:SetActiveTab(self.State.activeTab)
    end
end

function TB:Initialize()
    self:CreateMainFrame()
    self:SyncFilterControls()
    self:SetActiveTab("Browse")

    SLASH_TRADEBOARD1 = "/tradeboard"
    SLASH_TRADEBOARD2 = "/tb"
    SlashCmdList["TRADEBOARD"] = function()
        TB:Toggle()
    end

    local events = CreateFrame("Frame", nil, UIParent)
    events:RegisterEvent("PLAYER_ENTERING_WORLD")
    events:RegisterEvent("PLAYER_LEVEL_UP")
    events:SetScript("OnEvent", function()
        if event == "PLAYER_ENTERING_WORLD" then
            TB.Frames.main:Show()
            TB:SetActiveTab(TB.State.activeTab)
            DEFAULT_CHAT_FRAME:AddMessage("|cffffcc33TradeBoard|r UI prototype loaded. Type |cffffffff/tb|r to toggle it.")
        elseif event == "PLAYER_LEVEL_UP" then
            TB:UpdateBrowse()
        end
    end)
end

TB:Initialize()
