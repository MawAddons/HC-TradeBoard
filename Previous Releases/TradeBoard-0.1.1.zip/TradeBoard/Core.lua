TradeBoard = {}

TradeBoard.VERSION = "0.1.1"
TradeBoard.MAX_VISIBLE_ROWS = 7

TradeBoard.Quality = {
    [1] = { name = "Common", r = 1.00, g = 1.00, b = 1.00, hex = "ffffffff" },
    [2] = { name = "Uncommon / Magic", r = 0.12, g = 1.00, b = 0.12, hex = "ff1eff00" },
    [3] = { name = "Rare", r = 0.20, g = 0.50, b = 1.00, hex = "ff3399ff" },
    [4] = { name = "Epic", r = 0.70, g = 0.30, b = 1.00, hex = "ffb048ff" },
    [5] = { name = "Legendary", r = 1.00, g = 0.50, b = 0.05, hex = "ffff8000" },
}

TradeBoard.Categories = {
    "All Items",
    "Weapons",
    "Armor",
    "Containers",
    "Consumables",
    "Trade Goods",
    "Recipes",
    "Projectiles",
    "Quivers",
    "Miscellaneous",
}

TradeBoard.State = {
    activeTab = "Browse",
    category = "All Items",
    myLevelRange = 1,
    onlineOnly = 1,
    showSell = 1,
    showBuy = 1,
    levelType = "required",
    minLevel = 30,
    maxLevel = 40,
    search = "",
    rarities = {
        [1] = nil,
        [2] = 1,
        [3] = 1,
        [4] = 1,
        [5] = 1,
    },
    browseOffset = 0,
    selectedListing = nil,
    selectedChain = 1,
    sortKey = "unitPrice",
    sortAscending = 1,
}

function TradeBoard:GetPlayerLevel()
    local level = UnitLevel("player")
    if not level or level < 1 then
        return 30
    end
    return level
end

function TradeBoard:GetTraderRange()
    local level = self:GetPlayerLevel()
    local low = level - 5
    local high = level + 5
    if low < 1 then
        low = 1
    end
    if high > 60 then
        high = 60
    end
    return low, high
end

function TradeBoard:GetTraderRangeLabel()
    local low, high = self:GetTraderRange()
    return "My level range (" .. low .. "-" .. high .. ")"
end

function TradeBoard:FormatMoney(copper)
    local gold = math.floor(copper / 10000)
    local silver = math.floor(math.mod(copper, 10000) / 100)
    local coins = math.mod(copper, 100)
    local result = ""

    if gold > 0 then
        result = gold .. "g "
    end
    if silver > 0 or gold > 0 then
        result = result .. silver .. "s "
    end
    return result .. coins .. "c"
end

function TradeBoard:ColorText(text, quality)
    local info = self.Quality[quality] or self.Quality[1]
    return "|c" .. info.hex .. text .. "|r"
end

function TradeBoard:IsListingVisible(listing)
    local state = self.State

    if state.category ~= "All Items" and listing.category ~= state.category then
        return nil
    end

    if not state.rarities[listing.quality] then
        return nil
    end

    if listing.orderType == "SELL" and not state.showSell then
        return nil
    end
    if listing.orderType == "BUY" and not state.showBuy then
        return nil
    end

    if state.onlineOnly and not listing.online then
        return nil
    end

    if state.myLevelRange then
        local low, high = self:GetTraderRange()
        if listing.traderLevel < low or listing.traderLevel > high then
            return nil
        end
    end

    local level = listing.requiredLevel
    if state.levelType == "item" then
        level = listing.itemLevel
    end

    if state.minLevel and state.minLevel > 0 and level < state.minLevel then
        return nil
    end
    if state.maxLevel and state.maxLevel > 0 and level > state.maxLevel then
        return nil
    end

    if state.search and state.search ~= "" then
        local needle = string.lower(state.search)
        local haystack = string.lower(listing.name)
        if not string.find(haystack, needle, 1, 1) then
            return nil
        end
    end

    return 1
end

function TradeBoard:GetFilteredListings()
    local filtered = {}
    local count = table.getn(self.MockListings)
    local i

    for i = 1, count do
        if self:IsListingVisible(self.MockListings[i]) then
            table.insert(filtered, self.MockListings[i])
        end
    end

    local sortKey = self.State.sortKey
    local ascending = self.State.sortAscending

    table.sort(filtered, function(a, b)
        local aValue = a[sortKey]
        local bValue = b[sortKey]

        if sortKey == "name" or sortKey == "trader" then
            aValue = string.lower(aValue or "")
            bValue = string.lower(bValue or "")
        elseif sortKey == "online" then
            aValue = a.online and 1 or 0
            bValue = b.online and 1 or 0
        else
            aValue = aValue or 0
            bValue = bValue or 0
        end

        if aValue == bValue then
            local aName = string.lower(a.name or "")
            local bName = string.lower(b.name or "")
            if aName == bName then
                return string.lower(a.trader or "") < string.lower(b.trader or "")
            end
            return aName < bName
        end

        if ascending then
            return aValue < bValue
        end
        return aValue > bValue
    end)

    return filtered
end

function TradeBoard:SetSort(sortKey)
    if self.State.sortKey == sortKey then
        if self.State.sortAscending then
            self.State.sortAscending = nil
        else
            self.State.sortAscending = 1
        end
    else
        self.State.sortKey = sortKey
        self.State.sortAscending = 1
    end
    self.State.browseOffset = 0
end

function TradeBoard:ResetFilters()
    local state = self.State
    state.category = "All Items"
    state.myLevelRange = nil
    state.onlineOnly = nil
    state.showSell = 1
    state.showBuy = 1
    state.levelType = "required"
    state.minLevel = 0
    state.maxLevel = 0
    state.search = ""
    state.browseOffset = 0

    local quality
    for quality = 1, 5 do
        state.rarities[quality] = 1
    end
end

function TradeBoard:SetStatus(text)
    if self.Frames and self.Frames.statusText then
        self.Frames.statusText:SetText(text)
    end
end
