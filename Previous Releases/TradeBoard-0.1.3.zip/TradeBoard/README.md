# TradeBoard UI prototype

This is a World of Warcraft 1.12.1 UI prototype. It builds the visual shell for a community trade board and uses mocked listings. It does not join channels or send addon messages.

## Install

1. Copy the `TradeBoard` folder into `World of Warcraft\Interface\AddOns\`.
2. Confirm the final path is `Interface\AddOns\TradeBoard\TradeBoard.toc`.
3. Start the 1.12.1 client and enable **TradeBoard** on the character-selection AddOns screen.
4. Log in. TradeBoard stays closed until you open it.

Use `/tb`, `/tradeboard`, or left-click the coin icon beside the minimap to hide or show it. Hold Ctrl and left-drag the coin to move it around the minimap.

## Prototype features

- Browse, My Listings, and Trade Chains tabs.
- A classic minimap coin button for opening and closing TradeBoard.
- Search, category, rarity, trader-level, online, listing-type, and item-level filters.
- Simple Armor and Weapons subcategories without the full Auction House category tree.
- Toggle between Required Level and Item Level by clicking the level-type button.
- Click any table header to sort ascending or descending, including numeric unit-price sorting.
- Mouse-wheel scrolling over the result table.
- Press Enter to open normal chat, then Shift-left-click a mocked item to insert its item link.
- Mock listing selection and tooltips.
- Select a listing to open a whisper to its trader or request to add that trader to the friend list.
- Three mocked trade chains plus a local 12-slot editor for your own level 5-60 chain.
- The minimap-button position and your locally listed trade chain are saved between sessions.

## Intentionally absent

- Chat or addon-channel communication.
- Real bag/item selection.
- Automatic message sending or trade automation. The Whisper button only opens a pre-addressed chat edit box.
