# TradeBoard UI prototype

This is a local-only World of Warcraft 1.12.1 addon prototype. It builds the visual shell for a community trade board and uses mocked listings. It does not join channels, send addon messages, whisper players, or persist listings.

## Install

1. Copy the `TradeBoard` folder into `World of Warcraft\Interface\AddOns\`.
2. Confirm the final path is `Interface\AddOns\TradeBoard\TradeBoard.toc`.
3. Start the 1.12.1 client and enable **TradeBoard** on the character-selection AddOns screen.
4. Log in. The prototype opens automatically.

Use `/tb` or `/tradeboard` to hide or show it.

## Prototype features

- Browse, My Listings, and Trade Chains tabs.
- Search, category, rarity, trader-level, online, sell/buy, and item-level filters.
- Toggle between Required Level and Item Level by clicking the level-type button.
- Mouse-wheel scrolling over the result table.
- Mock listing selection and tooltips.
- Three mocked trade chains with every 5-level link from 5 to 60.

## Intentionally absent

- Chat or addon-channel communication.
- SavedVariables.
- Real bag/item selection.
- Real whispers or trade automation.
