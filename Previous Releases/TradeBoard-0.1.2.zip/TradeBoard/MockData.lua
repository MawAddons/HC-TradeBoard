TradeBoard.MockListings = {
    { name = "Green Iron Boots", texture = "Interface\\Icons\\INV_Boots_01", quality = 2, requiredLevel = 31, itemLevel = 35, quantity = 1, unitPrice = 22500, trader = "Thorgin", traderLevel = 5, category = "Armor", orderType = "SELL", online = 1 },
    { name = "Plans: Arcanite Reaper", texture = "Interface\\Icons\\INV_Scroll_03", quality = 3, requiredLevel = 35, itemLevel = 39, quantity = 1, unitPrice = 125000, trader = "Lyriana", traderLevel = 10, category = "Recipes", orderType = "SELL", online = 1 },
    { name = "Glyphcloak of the Owl", texture = "Interface\\Icons\\INV_Misc_Cape_11", quality = 4, requiredLevel = 33, itemLevel = 38, quantity = 1, unitPrice = 87500, trader = "Mareth", traderLevel = 15, category = "Armor", orderType = "SELL", online = 1 },
    { name = "Ancient Ember", texture = "Interface\\Icons\\Spell_Fire_Fire", quality = 5, requiredLevel = 37, itemLevel = 40, quantity = 1, unitPrice = 250000, trader = "Bromar", traderLevel = 20, category = "Miscellaneous", orderType = "SELL", online = 1 },
    { name = "Schematic: Thorium Rifle", texture = "Interface\\Icons\\INV_Scroll_06", quality = 3, requiredLevel = 35, itemLevel = 40, quantity = 1, unitPrice = 150000, trader = "Caldin", traderLevel = 25, category = "Recipes", orderType = "SELL", online = 1 },
    { name = "Devout Crown", texture = "Interface\\Icons\\INV_Crown_01", quality = 4, requiredLevel = 34, itemLevel = 39, quantity = 1, unitPrice = 104000, trader = "Jorlen", traderLevel = 30, category = "Armor", orderType = "SELL", online = 1 },
    { name = "Heavy Mithril Axe", texture = "Interface\\Icons\\INV_Axe_17", quality = 2, requiredLevel = 32, itemLevel = 37, quantity = 1, unitPrice = 36000, trader = "Redtusk", traderLevel = 35, category = "Weapons", orderType = "SELL", online = 1 },
    { name = "Blue Dragon Scale", texture = "Interface\\Icons\\INV_Misc_MonsterScales_09", quality = 3, requiredLevel = 30, itemLevel = 36, quantity = 8, unitPrice = 18500, trader = "Moonleaf", traderLevel = 40, category = "Trade Goods", orderType = "BUY", online = 1 },
    { name = "Traveler's Backpack", texture = "Interface\\Icons\\INV_Misc_Bag_08", quality = 2, requiredLevel = 30, itemLevel = 35, quantity = 1, unitPrice = 42000, trader = "Kelana", traderLevel = 45, category = "Containers", orderType = "SELL", online = 1 },
    { name = "Greater Mana Potion", texture = "Interface\\Icons\\INV_Potion_73", quality = 2, requiredLevel = 31, itemLevel = 35, quantity = 5, unitPrice = 9500, trader = "Silverbrew", traderLevel = 50, category = "Consumables", orderType = "SELL", online = 1 },
    { name = "Jagged Arrow", texture = "Interface\\Icons\\INV_Ammo_Arrow_03", quality = 1, requiredLevel = 30, itemLevel = 34, quantity = 200, unitPrice = 15, trader = "Falric", traderLevel = 55, category = "Projectiles", orderType = "BUY", online = 1 },
    { name = "Harpy Hide Quiver", texture = "Interface\\Icons\\INV_Misc_Quiver_02", quality = 3, requiredLevel = 36, itemLevel = 40, quantity = 1, unitPrice = 75500, trader = "Aelwyn", traderLevel = 60, category = "Quivers", orderType = "SELL", online = 1 },
    { name = "Iron Bar", texture = "Interface\\Icons\\INV_Ingot_Iron", quality = 1, requiredLevel = 30, itemLevel = 32, quantity = 20, unitPrice = 450, trader = "Stonehand", traderLevel = 28, category = "Trade Goods", orderType = "BUY", online = 1 },
    { name = "Heavy Leather", texture = "Interface\\Icons\\INV_Misc_LeatherScrap_07", quality = 1, requiredLevel = 30, itemLevel = 32, quantity = 15, unitPrice = 700, trader = "Ashpaw", traderLevel = 32, category = "Trade Goods", orderType = "SELL", online = 1 },
    { name = "Phantom Blade", texture = "Interface\\Icons\\INV_Sword_30", quality = 3, requiredLevel = 39, itemLevel = 44, quantity = 1, unitPrice = 185000, trader = "Grimar", traderLevel = 34, category = "Weapons", orderType = "SELL", online = nil },
    { name = "Dreamweave Gloves", texture = "Interface\\Icons\\INV_Gauntlets_17", quality = 2, requiredLevel = 40, itemLevel = 45, quantity = 1, unitPrice = 65000, trader = "Lyrana", traderLevel = 27, category = "Armor", orderType = "SELL", online = 1 },
    { name = "Elixir of Detect Demon", texture = "Interface\\Icons\\INV_Potion_53", quality = 2, requiredLevel = 32, itemLevel = 36, quantity = 3, unitPrice = 12500, trader = "Velis", traderLevel = 31, category = "Consumables", orderType = "BUY", online = 1 },
    { name = "Pattern: Big Voodoo Mask", texture = "Interface\\Icons\\INV_Scroll_05", quality = 2, requiredLevel = 38, itemLevel = 42, quantity = 1, unitPrice = 32000, trader = "Zulani", traderLevel = 33, category = "Recipes", orderType = "SELL", online = 1 },
}

TradeBoard.MockMyListings = {
    { name = "Heavy Leather", texture = "Interface\\Icons\\INV_Misc_LeatherScrap_07", quantity = 15, price = 700, quality = 1, status = "Active" },
    { name = "Greater Mana Potion", texture = "Interface\\Icons\\INV_Potion_73", quantity = 5, price = 9500, quality = 2, status = "Active" },
    { name = "Phantom Blade", texture = "Interface\\Icons\\INV_Sword_30", quantity = 1, price = 185000, quality = 3, status = "Paused" },
}

TradeBoard.MockChains = {
    {
        name = "Northern Caravan",
        crossFaction = 1,
        members = {
            { level = 5, name = "Arlen", online = 1 }, { level = 10, name = "Bromar", online = 1 },
            { level = 15, name = "Caldrin", online = 1 }, { level = 20, name = "Dorien", online = 1 },
            { level = 25, name = "Elandra", online = 1 }, { level = 30, name = "Falric", online = 1 },
            { level = 35, name = "Grimar", online = 1 }, { level = 40, name = "Garruk", online = 1 },
            { level = 45, name = "Helion", online = nil }, { level = 50, name = "Ilyssa", online = 1 },
            { level = 55, name = "Jorlen", online = 1 }, { level = 60, name = "Kaelen", online = nil },
        },
    },
    {
        name = "Iron Road",
        crossFaction = nil,
        members = {
            { level = 5, name = "Pebble", online = 1 }, { level = 10, name = "Anvil", online = nil },
            { level = 15, name = "Copper", online = 1 }, { level = 20, name = "Bronze", online = 1 },
            { level = 25, name = "Steel", online = nil }, { level = 30, name = "Mithril", online = 1 },
            { level = 35, name = "Truesilver", online = 1 }, { level = 40, name = "Thorium", online = 1 },
            { level = 45, name = "Ember", online = nil }, { level = 50, name = "Forge", online = 1 },
            { level = 55, name = "Hammer", online = nil }, { level = 60, name = "Ironlord", online = 1 },
        },
    },
    {
        name = "Moon & Tusk",
        crossFaction = 1,
        members = {
            { level = 5, name = "Seedling", online = 1 }, { level = 10, name = "Cub", online = 1 },
            { level = 15, name = "Sapling", online = nil }, { level = 20, name = "Fang", online = 1 },
            { level = 25, name = "Willow", online = 1 }, { level = 30, name = "Talon", online = nil },
            { level = 35, name = "Moonkin", online = 1 }, { level = 40, name = "Warhorn", online = 1 },
            { level = 45, name = "Starlight", online = 1 }, { level = 50, name = "Redmoon", online = 1 },
            { level = 55, name = "Ancient", online = nil }, { level = 60, name = "Earthsong", online = 1 },
        },
    },
}
